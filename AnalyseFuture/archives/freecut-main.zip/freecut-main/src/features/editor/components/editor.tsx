import { useEffect, useState, useRef, useCallback, memo, lazy, Suspense } from 'react'
import { useRouter } from '@tanstack/react-router'
import { useTranslation } from 'react-i18next'
import { createLogger, createOperationId } from '@/shared/logging/logger'
import { i18n } from '@/i18n'
import type { ImperativePanelHandle } from 'react-resizable-panels'
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from '@/components/ui/resizable'
import { ErrorBoundary } from '@/components/error-boundary'
import { Toolbar } from './toolbar'
import { MediaSidebar } from './media-sidebar'
import { PropertiesSidebar } from './properties-sidebar'
import { PreviewArea } from './preview-area'
import { MotionPreviewArea, MotionTimelineDock } from './compose-workspace/compose-layout'
import { InteractionLockRegion } from './interaction-lock-region'
import { AudioMeterPanel } from './audio-meter-panel'
import {
  importTimeline,
  importBentoLayoutDialog,
  importFillerRemovalDialog,
  importReverseConformDialog,
  importSilenceRemovalDialog,
  useBentoLayoutDialogStore,
  useFillerRemovalDialogStore,
  useReverseConformDialogStore,
  useSilenceRemovalDialogStore,
} from '@/features/editor/deps/timeline-ui'
import { toast } from 'sonner'
import { useEditorHotkeys } from '@/features/editor/hooks/use-editor-hotkeys'
import { useAutoSave } from '../hooks/use-auto-save'
import {
  useTimelineShortcuts,
  useTransitionBreakageNotifications,
} from '@/features/editor/deps/timeline-hooks'
import { initTransitionChainSubscription } from '@/features/editor/deps/timeline-subscriptions'
import {
  loadTimeline,
  saveTimeline,
  toggleSnap,
  useTimelineSettingsStore,
} from '@/features/editor/deps/timeline-store'
import { importBundleExportDialog } from '@/features/editor/deps/project-bundle'
import { useMediaLibraryStore } from '@/features/editor/deps/media-library'
import { useSettingsStore } from '@/features/editor/deps/settings'
import { useMaskEditorStore } from '@/features/editor/deps/preview'
import { usePlaybackStore } from '@/shared/state/playback'
import { useEditorStore } from '@/shared/state/editor'
import { clearPreviewAudioCache } from '@/features/editor/deps/composition-runtime'
import { useProjectStore } from '@/features/editor/deps/projects'
import {
  importExportDialog,
  importExportsDialog,
  RenderQueuePersistence,
  RenderQueueRunner,
  useRenderQueueStore,
} from '@/features/editor/deps/export-contract'
import { getEditorLayout, getEditorLayoutCssVars } from '@/config/editor-layout'
import { EDITOR_WORKSPACE_TIMELINE_SIZE, type EditorWorkspaceId } from '@/config/editor-workspaces'
import {
  createProjectUpgradeBackup,
  formatProjectUpgradeBackupName,
} from '@/features/editor/deps/projects'
import { useClearKeyframesDialogStore } from '@/shared/state/clear-keyframes-dialog'
import { useTtsGenerateDialogStore } from '@/shared/state/tts-generate-dialog'
import { useProjectMediaMatchDialogStore } from '@/shared/state/project-media-match-dialog'
import { rememberLastEditorProjectId } from '@/shared/projects/last-editor-project'
import {
  importEmbeddedSubtitleTrackPickerHost,
  importSubtitleScanProgressDialog,
  useEmbeddedSubtitlePickerStore,
  useSubtitleScanProgressStore,
} from '@/features/editor/deps/media-library'
import { IoDragReadout } from '@/shared/timeline/io-range'
const logger = createLogger('Editor')
const LazyTimeline = lazy(() => importTimeline().then(({ Timeline }) => ({ default: Timeline })))
const LazyColorGradingDock = lazy(() =>
  import('./color-grading-dock').then(({ ColorGradingDock }) => ({ default: ColorGradingDock })),
)
const LazyColorTimelineNavigator = lazy(() =>
  import('./color-timeline-navigator').then(({ ColorTimelineNavigator }) => ({
    default: ColorTimelineNavigator,
  })),
)
const EDITOR_PROJECT_ROUTE_ID = '/editor/$projectId'

function workspaceTimelineSizeStorageKey(workspace: EditorWorkspaceId): string {
  return `editor:workspaceTimelineSize:${workspace}`
}

function loadWorkspaceTimelineSize(workspace: EditorWorkspaceId): number | null {
  try {
    const raw = localStorage.getItem(workspaceTimelineSizeStorageKey(workspace))
    if (raw === null) return null
    const parsed = Number(raw)
    return Number.isFinite(parsed) ? parsed : null
  } catch {
    return null
  }
}

function saveWorkspaceTimelineSize(workspace: EditorWorkspaceId, size: number): void {
  try {
    localStorage.setItem(workspaceTimelineSizeStorageKey(workspace), String(size))
  } catch {
    /* noop */
  }
}
const LazyExportDialog = lazy(() =>
  importExportDialog().then((module) => ({
    default: module.ExportDialog,
  })),
)
const LazyBundleExportDialog = lazy(() =>
  importBundleExportDialog().then((module) => ({
    default: module.BundleExportDialog,
  })),
)
const LazyExportsDialog = lazy(() =>
  importExportsDialog().then((module) => ({
    default: module.ExportsDialog,
  })),
)
const LazyClearKeyframesDialog = lazy(() =>
  import('@/features/editor/components/clear-keyframes-dialog').then((module) => ({
    default: module.ClearKeyframesDialog,
  })),
)
const LazyTtsGenerateDialog = lazy(() =>
  import('@/features/editor/components/tts-generate-dialog').then((module) => ({
    default: module.TtsGenerateDialog,
  })),
)
const LazyProjectMediaMatchDialog = lazy(() =>
  import('@/features/editor/components/project-media-match-dialog').then((module) => ({
    default: module.ProjectMediaMatchDialog,
  })),
)
const LazyEmbeddedSubtitleTrackPickerHost = lazy(() =>
  importEmbeddedSubtitleTrackPickerHost().then((module) => ({
    default: module.EmbeddedSubtitleTrackPickerHost,
  })),
)
const LazySubtitleScanProgressDialog = lazy(() =>
  importSubtitleScanProgressDialog().then((module) => ({
    default: module.SubtitleScanProgressDialog,
  })),
)
const LazyBentoLayoutDialog = lazy(() =>
  importBentoLayoutDialog().then((module) => ({
    default: module.BentoLayoutDialog,
  })),
)
const LazyReverseConformDialog = lazy(() =>
  importReverseConformDialog().then((module) => ({
    default: module.ReverseConformDialog,
  })),
)
const LazySilenceRemovalDialog = lazy(() =>
  importSilenceRemovalDialog().then((module) => ({
    default: module.SilenceRemovalDialog,
  })),
)
const LazyFillerRemovalDialog = lazy(() =>
  importFillerRemovalDialog().then((module) => ({
    default: module.FillerRemovalDialog,
  })),
)
function preloadExportDialog() {
  return importExportDialog()
}

function preloadBundleExportDialog() {
  return importBundleExportDialog()
}

/** Project metadata passed from route loader (timeline loaded separately via loadTimeline) */
interface EditorProps {
  projectId: string
  project: {
    id: string
    name: string
    width: number
    height: number
    fps: number
    backgroundColor?: string
  }
  migration: {
    storedSchemaVersion: number
    currentSchemaVersion: number
    requiresUpgrade: boolean
  }
}

/**
 * Tracks the in-flight (or completed) upgrade-backup job per project. Module-
 * scoped so it survives StrictMode's double effect invocation and any remount —
 * the async create can't be cancelled once started, so without this the
 * auto-backup would run twice and create duplicate backups. Keyed by projectId
 * so a re-running effect for the same still-pending project reuses the existing
 * job and can transition out of the pending state, instead of a one-shot guard
 * that would leave the project stuck on the "upgrading" placeholder forever.
 */
const startedUpgradeBackups = new Map<string, Promise<void>>()

/**
 * Video Editor entrypoint.
 * Legacy projects are upgraded automatically: a backup on the original schema is
 * snapshotted first (best-effort safety net), then the editor loads. No prompt.
 */
export const Editor = memo(function Editor({ projectId, project, migration }: EditorProps) {
  const { t } = useTranslation()
  const [upgradeApproved, setUpgradeApproved] = useState(!migration.requiresUpgrade)
  const backupName = formatProjectUpgradeBackupName(
    project.name,
    migration.storedSchemaVersion,
    migration.currentSchemaVersion,
  )

  // Latest projectId, so a backup that finishes after the user navigated away
  // only approves the project it was actually started for.
  const currentProjectIdRef = useRef(projectId)
  currentProjectIdRef.current = projectId

  useEffect(() => {
    setUpgradeApproved(!migration.requiresUpgrade)
  }, [migration.requiresUpgrade, projectId])

  // Auto-backup then auto-upgrade. The backup keeps the pre-upgrade project on its
  // original schema; loading proceeds regardless so the user is never blocked.
  useEffect(() => {
    if (!migration.requiresUpgrade || upgradeApproved) return

    // Reuse this project's in-flight job (StrictMode re-invokes effects, and the
    // async create can't be cancelled once started) rather than bailing out
    // permanently — re-running the effect for the same still-pending project
    // must still be able to transition out of the placeholder state.
    const jobProjectId = projectId
    let job = startedUpgradeBackups.get(jobProjectId)
    if (!job) {
      job = (async () => {
        const opId = createOperationId()
        const event = logger.startEvent('project.upgradeBackup', opId)
        event.merge({
          projectId: jobProjectId,
          fromVersion: migration.storedSchemaVersion,
          toVersion: migration.currentSchemaVersion,
        })
        try {
          const backup = await createProjectUpgradeBackup(jobProjectId, {
            fromVersion: migration.storedSchemaVersion,
            toVersion: migration.currentSchemaVersion,
            backupName,
          })
          event.success({ status: 'created', backupName: backup.name })
          toast.success(t('editor.editor.backupCreated'), { description: backup.name })
        } catch (error) {
          event.failure(error, { status: 'failed' })
          toast.error(t('editor.editor.backupFailed'), {
            description: error instanceof Error ? error.message : t('editor.editor.tryAgain'),
          })
        }
      })()
      startedUpgradeBackups.set(jobProjectId, job)
    }

    let active = true
    void job.then(() => {
      // Only approve the upgrade for the project this job was started for; a late
      // completion after navigation must not unblock a different project.
      if (active && currentProjectIdRef.current === jobProjectId) {
        setUpgradeApproved(true)
      }
    })
    return () => {
      active = false
    }
  }, [
    migration.requiresUpgrade,
    migration.storedSchemaVersion,
    migration.currentSchemaVersion,
    upgradeApproved,
    projectId,
    backupName,
    t,
  ])

  if (!upgradeApproved) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-sm text-muted-foreground">
          {t('editor.editor.upgrading', { defaultValue: 'Upgrading project…' })}
        </div>
      </div>
    )
  }

  return <LoadedEditor projectId={projectId} project={project} migration={migration} />
})

const EditorDialogHost = memo(function EditorDialogHost({ projectId }: { projectId: string }) {
  const clearKeyframesDialogOpen = useClearKeyframesDialogStore((s) => s.isOpen)
  const ttsGenerateDialogOpen = useTtsGenerateDialogStore((s) => s.isOpen)
  const projectMediaMatchDialogOpen = useProjectMediaMatchDialogStore(
    (s) => s.isOpen && s.projectId === projectId,
  )
  const embeddedSubtitlePickerOpen = useEmbeddedSubtitlePickerStore((s) => s.media !== null)
  const subtitleScanProgressOpen = useSubtitleScanProgressStore((s) => s.open)

  return (
    <>
      {clearKeyframesDialogOpen && (
        <Suspense fallback={null}>
          <LazyClearKeyframesDialog />
        </Suspense>
      )}
      {projectMediaMatchDialogOpen && (
        <Suspense fallback={null}>
          <LazyProjectMediaMatchDialog projectId={projectId} />
        </Suspense>
      )}
      {ttsGenerateDialogOpen && (
        <Suspense fallback={null}>
          <LazyTtsGenerateDialog />
        </Suspense>
      )}
      {embeddedSubtitlePickerOpen && (
        <Suspense fallback={null}>
          <LazyEmbeddedSubtitleTrackPickerHost />
        </Suspense>
      )}
      {subtitleScanProgressOpen && (
        <Suspense fallback={null}>
          <LazySubtitleScanProgressDialog />
        </Suspense>
      )}
    </>
  )
})

const TimelineDialogHost = memo(function TimelineDialogHost() {
  const bentoLayoutOpen = useBentoLayoutDialogStore((s) => s.isOpen)
  const reverseConformOpen = useReverseConformDialogStore((s) => s.request !== null)
  const silenceRemovalOpen = useSilenceRemovalDialogStore((s) => s.isOpen)
  const fillerRemovalOpen = useFillerRemovalDialogStore((s) => s.isOpen)

  return (
    <>
      {bentoLayoutOpen && (
        <Suspense fallback={null}>
          <LazyBentoLayoutDialog />
        </Suspense>
      )}
      {reverseConformOpen && (
        <Suspense fallback={null}>
          <LazyReverseConformDialog />
        </Suspense>
      )}
      {silenceRemovalOpen && (
        <Suspense fallback={null}>
          <LazySilenceRemovalDialog />
        </Suspense>
      )}
      {fillerRemovalOpen && (
        <Suspense fallback={null}>
          <LazyFillerRemovalDialog />
        </Suspense>
      )}
    </>
  )
})

const AutoSaveController = memo(function AutoSaveController({
  onSave,
}: {
  onSave: () => Promise<void>
}) {
  const isDirty = useTimelineSettingsStore((s) => s.isDirty)
  useAutoSave({ isDirty, onSave })
  return null
})

const TimelineShortcutsController = memo(function TimelineShortcutsController() {
  useTimelineShortcuts()
  return null
})

export const LoadedEditor = memo(function LoadedEditor({
  projectId,
  project,
  migration,
}: EditorProps) {
  const { t } = useTranslation()
  const router = useRouter()
  const [exportDialogOpen, setExportDialogOpen] = useState(false)
  const [bundleExportDialogOpen, setBundleExportDialogOpen] = useState(false)
  const [renderQueueOpen, setRenderQueueOpen] = useState(false)
  const renderQueueActiveCount = useRenderQueueStore(
    (s) => s.jobs.filter((j) => j.status === 'queued' || j.status === 'rendering').length,
  )
  const [bundleFileHandle, setBundleFileHandle] = useState<FileSystemFileHandle | undefined>()
  const editorDensity = useSettingsStore((s) => s.editorDensity)
  const snapEnabledPreference = useSettingsStore((s) => s.snapEnabled)
  const editorLayout = getEditorLayout(editorDensity)
  const editorLayoutCssVars = getEditorLayoutCssVars(editorLayout)
  const syncSidebarLayout = useEditorStore((s) => s.syncSidebarLayout)
  const propertiesFullColumn = useEditorStore((s) => s.propertiesFullColumn)
  const mediaFullColumn = useEditorStore((s) => s.mediaFullColumn)
  const workspace = useEditorStore((s) => s.workspace)
  const isMaskEditingActive = useMaskEditorStore((s) => s.isEditing)
  const hasRefreshedMigrationStateRef = useRef(false)
  const timelinePanelRef = useRef<ImperativePanelHandle>(null)
  const previousWorkspaceRef = useRef(workspace)

  // Guard against concurrent saves (e.g., spamming Ctrl+S)
  const isSavingRef = useRef(false)

  useEffect(() => {
    hasRefreshedMigrationStateRef.current = false
  }, [projectId])

  useEffect(() => {
    rememberLastEditorProjectId(projectId)
  }, [projectId])

  // Initialize transition chain subscription (pre-computes chains from timeline data)
  // This subscription recomputes chains when items/transitions change - deferred to idle
  // time so it doesn't compete with the initial editor render.
  useEffect(() => {
    let unsubscribe: (() => void) | undefined
    const id = requestIdleCallback(() => {
      unsubscribe = initTransitionChainSubscription()
    })
    return () => {
      cancelIdleCallback(id)
      unsubscribe?.()
    }
  }, [])

  // Preload export dialogs during idle time so they open instantly.
  useEffect(() => {
    const id = requestIdleCallback(() => {
      // Best-effort idle preloads: swallow rejections (offline chunk load, or
      // the dynamic import racing test-environment teardown). The real load
      // happens later via lazy() at render time with its own error boundary.
      void preloadExportDialog().catch(() => {})
      void preloadBundleExportDialog().catch(() => {})
    })
    return () => cancelIdleCallback(id)
  }, [])

  // Prewarm effect preview thumbnails during idle time without making the
  // effects feature part of the initial editor route chunk.
  useEffect(() => {
    const id = requestIdleCallback(() => {
      // Best-effort prewarm — ignore failures, including the import() promise
      // rejecting when it resolves after the test environment is torn down.
      void import('@/features/editor/deps/effects-contract')
        .then((module) => module.prewarmEffectPreviews())
        .catch(() => {})
    })
    return () => cancelIdleCallback(id)
  }, [])

  // Initialize timeline from project data (or create default tracks for new projects).
  useEffect(() => {
    const { setCurrentProject: setMediaProject, loadMediaItems } = useMediaLibraryStore.getState()
    const { setCurrentProject } = useProjectStore.getState()
    const playbackStore = usePlaybackStore.getState()

    // Clear stale scrub preview from previous editor sessions.
    // A non-null previewFrame puts preview into "scrubbing" mode, which can
    // defer media URL resolution during project open.
    playbackStore.setPreviewFrame(null)

    // Set current project context for media library (v3: project-scoped media)
    setMediaProject(projectId)
    void loadMediaItems().catch((error) => {
      logger.error('Failed to load media library:', error)
    })

    // Set current project in project store for properties panel
    setCurrentProject({
      id: project.id,
      name: project.name,
      description: '',
      duration: 0,
      schemaVersion: migration.currentSchemaVersion,
      metadata: {
        width: project.width,
        height: project.height,
        fps: project.fps,
        backgroundColor: project.backgroundColor,
      },
      createdAt: Date.now(),
      updatedAt: Date.now(),
    })

    // Load timeline from IndexedDB - single source of truth for all timeline state
    let cancelled = false

    void (async () => {
      try {
        await loadTimeline(projectId, { allowProjectUpgrade: migration.requiresUpgrade })

        if (cancelled || !migration.requiresUpgrade || hasRefreshedMigrationStateRef.current) {
          return
        }

        hasRefreshedMigrationStateRef.current = true

        // Refresh the editor route metadata once the approved legacy project has
        // opened successfully so future reopens do not briefly show the upgrade prompt.
        await router.invalidate({
          filter: (match) =>
            match.routeId === EDITOR_PROJECT_ROUTE_ID && match.params.projectId === projectId,
        })
      } catch (error) {
        logger.error('Failed to load timeline:', error)
      }
    })()

    // Cleanup: clear project context, stop playback, and release blob URLs when leaving editor
    return () => {
      cancelled = true
      const cleanupPlaybackStore = usePlaybackStore.getState()
      cleanupPlaybackStore.setPreviewFrame(null)
      useMediaLibraryStore.getState().setCurrentProject(null)
      useProjectStore.getState().setCurrentProject(null)
      cleanupPlaybackStore.pause()
      clearPreviewAudioCache()
    }
  }, [
    migration.currentSchemaVersion,
    migration.requiresUpgrade,
    project.backgroundColor,
    project.fps,
    project.height,
    project.id,
    project.name,
    project.width,
    projectId,
    router,
  ])

  useEffect(() => {
    syncSidebarLayout(editorLayout)
  }, [editorLayout, syncSidebarLayout])

  // Apply the per-workspace timeline split when switching workspaces:
  // snapshot the outgoing workspace's split, then restore the incoming
  // workspace's saved split (or its preset default on first visit).
  useEffect(() => {
    const previousWorkspace = previousWorkspaceRef.current
    if (previousWorkspace === workspace) return
    previousWorkspaceRef.current = workspace

    // Workspace switches should not carry transient scrub/hover preview
    // frames across surfaces. Color scopes intentionally skip previewFrame
    // samples, so a stale Edit preview frame can make them appear frozen.
    usePlaybackStore.getState().setPreviewFrame(null)

    const timelinePanel = timelinePanelRef.current
    if (!timelinePanel) return

    saveWorkspaceTimelineSize(previousWorkspace, timelinePanel.getSize())

    const targetSize =
      loadWorkspaceTimelineSize(workspace) ??
      EDITOR_WORKSPACE_TIMELINE_SIZE[workspace] ??
      editorLayout.timelineDefaultSize
    timelinePanel.resize(
      Math.min(editorLayout.timelineMaxSize, Math.max(editorLayout.timelineMinSize, targetSize)),
    )
  }, [workspace, editorLayout])

  useEffect(() => {
    const { snapEnabled } = useTimelineSettingsStore.getState()
    if (snapEnabled !== snapEnabledPreference) {
      toggleSnap()
    }
  }, [snapEnabledPreference])

  useEffect(() => {
    if (!isMaskEditingActive) return
    const activeElement = document.activeElement
    if (activeElement instanceof HTMLElement) {
      activeElement.blur()
    }
  }, [isMaskEditingActive])

  // Save timeline to project (with guard against concurrent saves)
  const handleSave = useCallback(async () => {
    // Prevent concurrent saves (e.g., spamming Ctrl+S)
    if (isSavingRef.current) {
      return
    }

    isSavingRef.current = true

    try {
      await saveTimeline(projectId)
      logger.debug('Project saved successfully')
      toast.success(i18n.t('editor.editor.projectSaved'))
    } catch (error) {
      logger.error('Failed to save project:', error)
      toast.error(i18n.t('editor.editor.projectSaveFailed'))
      throw error // Re-throw so callers know save failed
    } finally {
      isSavingRef.current = false
    }
  }, [projectId])

  const handleExport = useCallback(() => {
    // Pause playback when opening export dialog
    usePlaybackStore.getState().pause()
    void preloadExportDialog()
    setExportDialogOpen(true)
  }, [])

  const handleOpenRenderQueue = useCallback(() => {
    void importExportsDialog()
    setRenderQueueOpen(true)
  }, [])

  const handleExportBundle = useCallback(async () => {
    void preloadBundleExportDialog()

    // Show native save picker BEFORE opening the modal dialog to avoid
    // focus-loss conflicts between the native picker and Radix Dialog.
    if (typeof window.showSaveFilePicker === 'function') {
      const safeName = project.name
        .replace(/[<>:"/\\|?*]/g, '_')
        .replace(/\s+/g, '_')
        .substring(0, 100)
      try {
        const handle = await window.showSaveFilePicker({
          suggestedName: `${safeName}.freecut.zip`,
          types: [
            {
              description: i18n.t('editor.editor.projectBundle'),
              accept: { 'application/zip': ['.freecut.zip'] },
            },
          ],
        })
        setBundleFileHandle(handle)
      } catch {
        // User cancelled the picker - don't open the dialog
        return
      }
    } else {
      setBundleFileHandle(undefined)
    }

    setBundleExportDialogOpen(true)
  }, [project.name])

  // Enable keyboard shortcuts
  useEditorHotkeys({
    onSave: handleSave,
    onExport: handleExport,
  })

  // Enable transition breakage notifications
  useTransitionBreakageNotifications()

  const timelineDuration = 30
  const isColorWorkspace = workspace === 'color'
  const isMotionWorkspace = workspace === 'motion'
  // Color replaces the default editor shell. Motion deliberately keeps it and
  // swaps the preview/timeline surfaces while retaining the shared sidebars.
  const hidesDefaultSidebars = isColorWorkspace

  return (
    <div
      className="h-screen bg-background flex flex-col overflow-hidden"
      style={editorLayoutCssVars as import('react').CSSProperties}
      role="application"
      aria-label={t('editor.editor.appLabel')}
    >
      <AutoSaveController onSave={handleSave} />
      <TimelineShortcutsController />

      {/* Top Toolbar */}
      <InteractionLockRegion locked={isMaskEditingActive}>
        <Toolbar
          projectId={projectId}
          project={project}
          onSave={handleSave}
          onExport={handleExport}
          onExportBundle={handleExportBundle}
          onOpenRenderQueue={handleOpenRenderQueue}
          renderQueueCount={renderQueueActiveCount}
        />
      </InteractionLockRegion>

      {/* Main Layout: Full-height sidebar + vertical split */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Sidebar - Media Library (full column mode) */}
        {mediaFullColumn && !hidesDefaultSidebars && (
          <InteractionLockRegion locked={isMaskEditingActive}>
            <ErrorBoundary level="feature">
              <MediaSidebar />
            </ErrorBoundary>
          </InteractionLockRegion>
        )}

        {/* Right side: Preview/Properties + Timeline */}
        {isColorWorkspace ? (
          <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
            <div className="flex min-h-0 flex-1 flex-col overflow-hidden">
              <ErrorBoundary level="feature">
                <PreviewArea project={project} />
              </ErrorBoundary>
            </div>
            <Suspense fallback={null}>
              <LazyColorTimelineNavigator />
            </Suspense>
            <InteractionLockRegion
              locked={isMaskEditingActive}
              className="h-[37%] min-h-[288px] max-h-[39vh] shrink-0"
            >
              <ErrorBoundary level="feature">
                <Suspense fallback={null}>
                  <LazyColorGradingDock />
                </Suspense>
              </ErrorBoundary>
            </InteractionLockRegion>
          </div>
        ) : (
          <ResizablePanelGroup
            direction="vertical"
            className="flex-1 min-w-0"
            autoSaveId="editor:timeline-layout"
          >
            {/* Top - Preview + Properties (inline mode) */}
            <ResizablePanel
              defaultSize={100 - editorLayout.timelineDefaultSize}
              minSize={100 - editorLayout.timelineMaxSize}
              maxSize={100 - editorLayout.timelineMinSize}
            >
              <div className="h-full flex overflow-hidden relative">
                {/* Left Sidebar - Media Library (inline with preview) */}
                {!mediaFullColumn && (
                  <InteractionLockRegion locked={isMaskEditingActive}>
                    <ErrorBoundary level="feature">
                      <MediaSidebar />
                    </ErrorBoundary>
                  </InteractionLockRegion>
                )}

                {/* Center - Preview */}
                <ErrorBoundary level="feature">
                  {isMotionWorkspace ? (
                    <MotionPreviewArea project={project} />
                  ) : (
                    <PreviewArea project={project} />
                  )}
                </ErrorBoundary>

                {/* Right Sidebar - Properties (inline with preview) */}
                {!propertiesFullColumn && (
                  <InteractionLockRegion locked={isMaskEditingActive}>
                    <ErrorBoundary level="feature">
                      <PropertiesSidebar />
                    </ErrorBoundary>
                  </InteractionLockRegion>
                )}
              </div>
            </ResizablePanel>

            <ResizableHandle
              withHandle
              className={isMaskEditingActive ? 'pointer-events-none opacity-60' : undefined}
            />

            {/* Bottom - Timeline */}
            <ResizablePanel
              ref={timelinePanelRef}
              defaultSize={editorLayout.timelineDefaultSize}
              minSize={editorLayout.timelineMinSize}
              maxSize={editorLayout.timelineMaxSize}
            >
              <InteractionLockRegion locked={isMaskEditingActive} className="h-full">
                <ErrorBoundary level="feature">
                  <div className="h-full flex overflow-hidden">
                    <div className="min-w-0 flex-1">
                      {isMotionWorkspace ? (
                        <MotionTimelineDock project={project} />
                      ) : (
                        <Suspense fallback={null}>
                          <LazyTimeline duration={timelineDuration} />
                        </Suspense>
                      )}
                    </div>
                    <AudioMeterPanel />
                  </div>
                </ErrorBoundary>
              </InteractionLockRegion>
            </ResizablePanel>
          </ResizablePanelGroup>
        )}

        {/* Right Sidebar - Properties (full column mode) */}
        {propertiesFullColumn && !hidesDefaultSidebars && (
          <InteractionLockRegion locked={isMaskEditingActive}>
            <ErrorBoundary level="feature">
              <PropertiesSidebar />
            </ErrorBoundary>
          </InteractionLockRegion>
        )}
      </div>

      <Suspense fallback={null}>
        {/* Export Dialog */}
        {exportDialogOpen && (
          <LazyExportDialog
            open={exportDialogOpen}
            onClose={() => setExportDialogOpen(false)}
            onOpenRenderQueue={handleOpenRenderQueue}
          />
        )}

        {/* Exports + render queue dialog */}
        {renderQueueOpen && (
          <LazyExportsDialog
            open={renderQueueOpen}
            onClose={() => setRenderQueueOpen(false)}
            projectId={projectId}
          />
        )}

        {/* Bundle Export Dialog */}
        {bundleExportDialogOpen && (
          <LazyBundleExportDialog
            open={bundleExportDialogOpen}
            onClose={() => {
              setBundleExportDialogOpen(false)
              setBundleFileHandle(undefined)
            }}
            projectId={projectId}
            onBeforeExport={handleSave}
            fileHandle={bundleFileHandle}
          />
        )}
      </Suspense>

      {/* Restores/persists the per-project queue, and drains it serially. */}
      <RenderQueuePersistence projectId={projectId} />
      <RenderQueueRunner />

      <EditorDialogHost projectId={projectId} />
      <TimelineDialogHost />

      {/* Single global cursor-readout for IO (in/out) drags across all surfaces. */}
      <IoDragReadout />
    </div>
  )
})
